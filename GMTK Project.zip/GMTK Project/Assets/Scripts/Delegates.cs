﻿using UnityEngine;
using System;

public class Delegates : MonoBehaviour
{
   public delegate void EmptyDelegate();

    public delegate void IntDelegate(int num);
}
